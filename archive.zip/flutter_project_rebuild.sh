#!/bin/bash

# ==========================================
# Flutter项目重构自动化脚本
# 用于解决"unsupported Gradle project"错误
# ==========================================

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否在项目根目录
if [ ! -f "pubspec.yaml" ]; then
    log_error "请在Flutter项目根目录运行此脚本！"
    exit 1
fi

# 获取当前项目名
PROJECT_NAME=$(grep "^name:" pubspec.yaml | awk '{print $2}')
log_info "当前项目名称: $PROJECT_NAME"

# 检查Flutter是否安装
if ! command -v flutter &> /dev/null; then
    log_error "Flutter未安装或不在PATH中！"
    exit 1
fi

# 检查Git是否配置
if [ -z "$(git config --global user.name)" ] || [ -z "$(git config --global user.email)" ]; then
    log_warning "Git未完全配置，请先设置用户信息："
    echo "git config --global user.name \"你的名字\""
    echo "git config --global user.email \"你的邮箱\""
    read -p "按回车键继续..."
fi

log_info "开始Flutter项目重构过程..."

# 1. 创建备份目录
BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
log_info "创建备份目录: $BACKUP_DIR"

mkdir -p "$BACKUP_DIR"

# 2. 备份重要文件
log_info "备份重要文件..."

# 备份Dart代码
if [ -d "lib" ]; then
    cp -r lib "$BACKUP_DIR/"
    log_success "✓ 备份lib/目录"
fi

# 备份assets
if [ -d "assets" ]; then
    cp -r assets "$BACKUP_DIR/"
    log_success "✓ 备份assets/目录"
fi

# 备份pubspec.yaml
if [ -f "pubspec.yaml" ]; then
    cp pubspec.yaml "$BACKUP_DIR/"
    log_success "✓ 备份pubspec.yaml"
fi

# 备份其他重要文件
for file in README.md ANDROID_CONFIG.md DEPLOYMENT_GUIDE.md GITHUB_ACTIONS_USAGE.md; do
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_DIR/"
        log_success "✓ 备份$file"
    fi
done

# 备份.github（如果存在）
if [ -d ".github" ]; then
    cp -r .github "$BACKUP_DIR/"
    log_success "✓ 备份.github/目录"
fi

# 3. 创建临时目录
TEMP_DIR="temp_rebuild_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$TEMP_DIR"

# 4. 创建新的Flutter项目
log_info "创建新的Flutter项目..."
flutter create -t app "$TEMP_DIR/$PROJECT_NAME"

# 5. 复制代码到新项目
NEW_PROJECT="$TEMP_DIR/$PROJECT_NAME"
log_info "复制代码到新项目: $NEW_PROJECT"

# 复制Dart代码
if [ -d "$BACKUP_DIR/lib" ]; then
    rm -rf "$NEW_PROJECT/lib"
    cp -r "$BACKUP_DIR/lib" "$NEW_PROJECT/"
    log_success "✓ 复制lib/目录"
fi

# 复制assets
if [ -d "$BACKUP_DIR/assets" ]; then
    rm -rf "$NEW_PROJECT/assets"
    cp -r "$BACKUP_DIR/assets" "$NEW_PROJECT/"
    log_success "✓ 复制assets/目录"
fi

# 复制pubspec.yaml（合并依赖）
log_info "更新pubspec.yaml..."
cp "$BACKUP_DIR/pubspec.yaml" "$NEW_PROJECT/pubspec.yaml"

# 复制其他文档文件
for file in "$BACKUP_DIR"/*.{md,yml,yaml} "$BACKUP_DIR"/README.md "$BACKUP_DIR"/GITHUB_ACTIONS_USAGE.md; do
    if [ -f "$file" ]; then
        filename=$(basename "$file")
        cp "$file" "$NEW_PROJECT/$filename"
    fi
done

# 复制.github
if [ -d "$BACKUP_DIR/.github" ]; then
    rm -rf "$NEW_PROJECT/.github"
    cp -r "$BACKUP_DIR/.github" "$NEW_PROJECT/"
    log_success "✓ 复制.github/目录"
fi

# 6. 更新新项目的依赖
log_info "更新依赖包..."
cd "$NEW_PROJECT"
flutter pub get
log_success "✓ 依赖包更新完成"

# 7. 清理临时目录
cd ..
log_info "清理临时文件..."
rm -rf "$TEMP_DIR"

# 8. 验证新项目
log_info "验证新项目结构..."
if [ -f "$NEW_PROJECT/lib/main.dart" ] && [ -d "$NEW_PROJECT/lib" ]; then
    log_success "✓ main.dart存在"
else
    log_error "✗ main.dart不存在，请检查！"
fi

if [ -f "$NEW_PROJECT/pubspec.yaml" ]; then
    log_success "✓ pubspec.yaml存在"
else
    log_error "✗ pubspec.yaml不存在，请检查！"
fi

# 9. 测试构建
log_info "测试项目构建..."
cd "$NEW_PROJECT"
flutter build apk --debug > ../build_test.log 2>&1 || {
    log_warning "构建测试失败，查看build_test.log了解详情"
    cd ..
    log_error "重构失败！"
    exit 1
}
cd ..

log_success "✓ 构建测试通过"

# 10. 准备Git提交
log_info "准备Git提交..."

# 检查是否有未提交的更改
if [ -d ".git" ]; then
    if ! git diff --quiet; then
        log_warning "有未提交的更改，建议先提交当前的更改"
        read -p "是否继续？(y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "操作已取消"
            exit 0
        fi
    fi
fi

# 11. 移动新项目文件到当前目录
log_info "替换当前项目文件..."
# 删除旧的Flutter文件（保留备份）
rm -rf lib assets pubspec.yaml README.md
rm -rf .github 2>/dev/null || true

# 移动新项目文件
cp -r "$NEW_PROJECT"/* .
cp -r "$NEW_PROJECT"/.[^.]* . 2>/dev/null || true

# 12. 清理
rm -rf "$NEW_PROJECT"
rmdir "$TEMP_DIR" 2>/dev/null || true

# 13. 验证最终结果
log_info "验证最终项目结构..."
if [ -f "lib/main.dart" ] && [ -f "pubspec.yaml" ]; then
    log_success "✓ 项目结构验证通过"
else
    log_error "✗ 项目结构验证失败！"
    exit 1
fi

# 14. Git提交
log_info "执行Git提交..."
git add .
git commit -m "feat: 重构Flutter项目解决Gradle配置问题

- 使用flutter create重建项目结构
- 保留所有Dart代码和功能
- 修复Android Gradle配置
- 更新项目依赖和配置
- 保留文档和CI/CD配置

这个提交解决了'supported Gradle project'错误，
现在项目应该可以正常构建和运行。" || {
    log_warning "Git提交失败，可能是没有更改或Git未配置"
}

# 15. 最终清理
if [ -d "$BACKUP_DIR" ]; then
    log_info "保留备份目录: $BACKUP_DIR（您可以安全删除）"
fi

# 16. 完成
log_success "=========================================="
log_success "Flutter项目重构完成！"
log_success "=========================================="
log_info "现在您可以："
echo "1. git push origin main  # 推送到远程仓库"
echo "2. 访问GitHub Actions页面测试CI/CD"
echo "3. 本地测试: flutter run"
echo ""
log_info "如有问题，请检查："
echo "- build_test.log (构建日志)"
echo "- $BACKUP_DIR (备份文件)"
echo ""

read -p "是否立即推送到GitHub？(y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "推送到GitHub..."
    git push origin main
    log_success "已推送到GitHub！"
fi

log_success "项目重构流程结束！"
