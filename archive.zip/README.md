# 🍳 菜谱大全 - Flutter应用

[![Flutter Project Configuration Fix](https://github.com/your-username/recipe-app/actions/workflows/fix-flutter-config.yml/badge.svg)](https://github.com/your-username/recipe-app/actions/workflows/fix-flutter-config.yml)

一个精美的Flutter中式菜谱管理应用，包含10个经典菜谱的详细制作步骤。

## 📱 应用截图

![菜谱大全](assets/images/宫保鸡丁.jpg)

## ✨ 主要功能

- 📚 **10个经典中式菜谱** - 包含详细制作步骤
- 🎨 **Material Design 3** - 现代化界面设计
- 💾 **SQLite数据库** - 本地数据存储
- 🖼️ **高清美食图片** - 提升视觉体验
- 📱 **响应式设计** - 支持多种屏幕尺寸
- 🔍 **搜索和分类** - 快速找到想要的菜谱

## 🛠️ 技术栈

- **框架**: Flutter 3.35.8
- **语言**: Dart 3.9.2
- **状态管理**: Provider
- **数据库**: SQLite
- **UI框架**: Material Design 3
- **平台**: Android 5.0+ (API 21+)

## 📦 项目结构

```
recipe_app/
├── .github/
│   └── workflows/
│       └── fix-flutter-config.yml    # 自动配置修复工作流
├── lib/
│   ├── main.dart                      # 应用入口
│   ├── models/
│   │   └── recipe.dart               # 菜谱数据模型
│   ├── providers/
│   │   └── recipe_provider.dart      # 状态管理
│   ├── screens/
│   │   ├── home_screen.dart          # 主页
│   │   └── recipe_detail_screen.dart # 菜谱详情
│   ├── widgets/
│   │   └── recipe_card.dart          # 菜谱卡片组件
│   └── database/
│       └── recipe_database.dart      # 数据库操作
├── assets/
│   ├── images/                       # 菜谱图片
│   │   ├── 宫保鸡丁.jpg
│   │   ├── 麻婆豆腐.jpg
│   │   └── ... (更多菜谱图片)
│   └── data/                         # 应用数据
├── android/                          # Android配置文件
├── pubspec.yaml                      # 依赖配置
└── README.md                         # 项目说明
```

## 🚀 快速开始

### 1. 克隆项目
```bash
git clone <repository-url>
cd recipe_app
```

### 2. 安装依赖
```bash
flutter pub get
```

### 3. 运行应用
```bash
flutter run
```

### 4. 构建APK
```bash
# Debug版本
flutter build apk --debug

# Release版本
flutter build apk --release
```

## 🤖 GitHub Actions - 云端自动修复

### 全新工作流 (推荐)
我们提供了**完全自动化的GitHub Actions工作流**，可以直接在云端解决所有Flutter构建问题：

```yaml
name: Flutter Project Configuration Fix & Build
```

**关键特性**:
- 🔨 **自动重建项目** - 智能检测并重建Flutter项目结构
- ⚙️ **现代配置** - 应用最新Flutter Android标准配置
- 🚀 **一键构建** - 自动生成并上传APK文件
- 🤖 **零本地操作** - 完全在云端完成，无需本地环境

### 📋 工作流使用步骤
1. **推送代码到GitHub** (参考: [PUSH_TO_GITHUB_GUIDE.md](PUSH_TO_GITHUB_GUIDE.md))
2. **访问GitHub Actions页面**
3. **点击"Run workflow"**
4. **配置选项并执行** (首次使用选择Debug build和Force rebuild)
5. **下载生成的APK**

### 📁 核心文件
- `GITHUB_ACTIONS_GUIDE.md` - 详细工作流使用指南
- `SOLUTION_SUMMARY.md` - 完整解决方案总结
- `QUICK_REBUILD_GUIDE.md` - 快速重建参考
- `PUSH_TO_GITHUB_GUIDE.md` - 推送和配置指南

### 旧方法 (备用)
如需使用本地脚本，请参考: [GITHUB_ACTIONS_USAGE.md](GITHUB_ACTIONS_USAGE.md)

## 🔄 项目重构指南

如果遇到"unsupported Gradle project"错误，我们提供两种解决方案：

### 方案1：使用重构脚本（推荐）
```bash
# 运行自动重构脚本
./flutter_project_rebuild.sh
```

这个脚本会：
- 备份您的重要文件
- 使用Flutter官方推荐的方法重建项目
- 保留所有Dart代码和功能
- 自动提交到Git

详细说明请参考: [FLUTTER_REBUILD_GUIDE.md](FLUTTER_REBUILD_GUIDE.md)

### 方案2：手动重构
如果自动脚本失败，您可以手动执行：

```bash
# 1. 备份重要文件
cp -r lib /tmp/lib_backup
cp -r assets /tmp/assets_backup
cp pubspec.yaml /tmp/pubspec_backup

# 2. 删除旧项目（保留备份）
# 3. 创建新项目
flutter create -t app recipe_app

# 4. 复制文件回新项目
cp -r /tmp/lib_backup/* recipe_app/lib/
cp -r /tmp/assets_backup/* recipe_app/assets/
cp /tmp/pubspec_backup recipe_app/pubspec.yaml

# 5. 重新获取依赖
cd recipe_app
flutter pub get
```

## 📋 菜谱列表

1. **宫保鸡丁** - 经典川菜
2. **麻婆豆腐** - 四川名菜
3. **红烧肉** - 家常经典
4. **糖醋里脊** - 酸甜美味
5. **蒸蛋羹** - 嫩滑爽口
6. **酸辣汤** - 开胃暖胃
7. **白切鸡** - 粤菜经典
8. **回锅肉** - 川菜代表
9. **鱼香肉丝** - 川菜名品
10. **小笼包** - 上海特色

## 🔧 本地开发

### 环境要求
- Flutter SDK 3.35.8+
- Dart SDK 3.9.2+
- Android Studio / VS Code
- Android SDK

### 调试命令
```bash
# 分析代码
flutter analyze

# 运行测试
flutter test

# 清理项目
flutter clean

# 重新获取依赖
flutter pub get
```

## 📊 构建状态

| 平台 | 状态 | 说明 |
|------|------|------|
| Android | ✅ 稳定 | 支持API 21+ |
| Web | 🚧 计划中 | 后续支持 |
| iOS | 🚧 计划中 | 后续支持 |

## 🤝 贡献指南

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开Pull Request

## 📄 许可证

本项目使用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

- Flutter团队提供的优秀框架
- Material Design设计规范
- 开源社区的支持

## 📞 联系方式

如有问题或建议，请通过以下方式联系：
- 提交Issue到GitHub仓库
- 发送邮件到项目维护者

---

⭐ 如果这个项目对您有帮助，请给个Star支持！⭐