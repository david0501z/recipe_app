#!/bin/bash

# ==========================================
# Git提交和推送脚本
# ==========================================

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查Git配置
if [ -z "$(git config --global user.name)" ] || [ -z "$(git config --global user.email)" ]; then
    log_error "请先配置Git用户信息："
    echo "git config --global user.name \"您的姓名\""
    echo "git config --global user.email \"您的邮箱\""
    exit 1
fi

# 检查是否在Git仓库中
if [ ! -d ".git" ]; then
    log_info "初始化Git仓库..."
    git init
    git remote add origin https://github.com/your-username/recipe_app.git 2>/dev/null || true
    log_warning "请手动设置远程仓库地址："
    echo "git remote set-url origin https://github.com/your-username/recipe_app.git"
fi

# 检查是否有更改
if ! git diff --quiet; then
    log_info "检测到有更改的文件："
    git status --short
    echo
    read -p "是否提交这些更改？(y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        log_info "添加文件到Git..."
        git add .
        
        log_info "提交更改..."
        git commit -m "feat: 重构Flutter项目解决Gradle配置问题

- 使用flutter create重建项目结构
- 保留所有Dart代码和功能  
- 修复Android Gradle配置
- 更新项目依赖和配置
- 保留文档和CI/CD配置

这个提交解决了'supported Gradle project'错误，
现在项目应该可以正常构建和运行。"
        
        log_success "更改已提交到本地仓库"
        
        # 推送到远程
        echo
        read -p "是否推送到GitHub？(y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            log_info "推送到GitHub..."
            if git remote get-url origin > /dev/null 2>&1; then
                git push -u origin main || {
                    log_error "推送失败！请检查："
                    echo "1. 网络连接是否正常"
                    echo "2. GitHub仓库地址是否正确"
                    echo "3. 是否有推送权限"
                    exit 1
                }
                log_success "已推送到GitHub！"
            else
                log_error "未配置远程仓库地址，请先设置："
                echo "git remote add origin https://github.com/your-username/recipe_app.git"
                echo "git push -u origin main"
            fi
        fi
    else
        log_info "已取消提交"
    fi
else
    log_info "没有检测到更改的文件"
    echo "您可能需要："
    echo "1. 运行 ./flutter_project_rebuild.sh 重构项目"
    echo "2. 或者手动修改了一些文件但未保存"
fi

# 显示当前状态
echo
log_info "当前Git状态："
git status --short

# 显示远程仓库信息
if git remote get-url origin > /dev/null 2>&1; then
    log_info "远程仓库："
    git remote -v
else
    log_warning "未配置远程仓库"
fi

log_success "Git操作完成！"
